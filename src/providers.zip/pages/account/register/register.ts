import { Component } from '@angular/core';
import { NavController, IonicPage } from 'ionic-angular';
import {Service} from '../../../providers/service/service';
import { Functions } from '../../../providers/service/functions';
import { Values } from '../../../providers/service/values';
import { Home } from '../../home/home';

@IonicPage()
@Component({
    templateUrl: 'register.html'
})
export class AccountRegister {
    registerData: any;
    loadRegister: any;
    countries: any;
    status: any;
    public disableSubmit: boolean = false;
    errors: any;
    loginStatus: any;
    country: any;
    billing_states: any;
    shipping_states: any;
    Register: any;
    constructor(public nav: NavController, public service: Service, public functions: Functions, public values: Values) {
        this.Register = "Register Account";
        this.registerData = {};
        this.countries = {};
        this.registerData.billing_address = {};
        this.registerData.shipping_address = {};
        this.service.getNonce()
            .then((results) => this.handleResults(results));
    }
    handleResults(results) {
        this.countries = results;
    }
    getBillingRegion(countryId) {
        this.billing_states = this.countries.state[countryId];
    }
    getShippingRegion(countryId) {
        this.shipping_states = this.countries.state[countryId];
    }
    validateForm() {
        if (this.registerData.first_name == undefined || this.registerData.firstname == "") {
            this.functions.showAlert("ERROR", "Please Enter First Name");
            return false
        }
        if (this.registerData.last_name == undefined || this.registerData.lastname == "") {
            this.functions.showAlert("ERROR", "Please Enter Last Name ");
            return false
        }
        if (this.registerData.email == undefined || this.registerData.email == "") {
            this.functions.showAlert("ERROR", "Please Enter Email ID");
            return false
        }
        if (this.registerData.password == undefined || this.registerData.password == "") {
            this.functions.showAlert("ERROR", "Please Enter Password");
            return false
        }
        this.registerData.username = this.registerData.email;
        this.registerData.billing_address.email = this.registerData.email;
        this.registerData.billing_address.first_name = this.registerData.first_name;
        this.registerData.billing_address.last_name = this.registerData.last_name;
        this.registerData.shipping_address.first_name = this.registerData.first_name;
        this.registerData.shipping_address.last_name = this.registerData.last_name;
        this.registerData.shipping_address.company = this.registerData.billing_address.company;
        this.registerData.shipping_address.address_1 = this.registerData.billing_address.address_1;
        this.registerData.shipping_address.address_2 = this.registerData.billing_address.address_2;
        this.registerData.shipping_address.city = this.registerData.billing_address.city;
        this.registerData.shipping_address.state = this.registerData.billing_address.state;
        this.registerData.shipping_address.postcode = this.registerData.billing_address.postcode;
        this.registerData.shipping_address.country = this.registerData.billing_address.country;
        return true;
    }
    registerCustomer() {
        if (this.validateForm()) {
            this.disableSubmit = true;
            this.Register = "Registering";
            this.service.registerCustomer(this.registerData)
                .then((results) => this.handleRegister(results));
        }
    }
    handleRegister(results) {
        this.disableSubmit = false;
        this.Register = "Register Account";

        if(results.errors[0].code == "customer_invalid_email"){
           this.functions.showAlert("ERROR", results.errors[0].message);
        }


        else if (!results.errors) {
            this.countries.checkout_login;
            this.service.login(this.registerData, this.countries.checkout_login)
                .then((results) => this.loginStatus = results);
            
            this.registerData.device_id = this.values.deviceId;
            this.registerData.platform = this.values.platform;
            this.registerData.email = this.registerData.email;
            this.registerData.city = this.registerData.billing_address.city;
            this.registerData.state = this.registerData.billing_address.state;
            this.registerData.country = this.registerData.billing_address.country;
            this.registerData.pincode = this.registerData.billing_address.postcode;

             this.service.pushNotification(this.registerData)
                .then((results) => this.status = results);

            this.nav.setRoot(Home);
        }
        else if (results.errors) {
            this.errors = results.errors;
        }
    }
}